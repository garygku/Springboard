# DataScienceGuidedCapstone

Hello students!
Welcome to the Data Science Guided Capstone! 

Start by forking this repository to your personal GitHub account and cloning the fork to your local machine. 

You will find instructions on how to complete and submit each step of the Guided Capstone in the course materials. Each subunit will focus on one step of the Capstone, corresponding to a step of the Data Science Method. Find the Jupyter Notebook corresponding to the subunit you are working on, and open it. Follow along as you are guided through the work, and fill in the blanks!

When you are done with the notebook, push the changes to your personal GitHub accou t.
